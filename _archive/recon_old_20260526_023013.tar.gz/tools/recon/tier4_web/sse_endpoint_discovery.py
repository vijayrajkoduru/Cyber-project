"""SSE endpoint discovery — VL-FORGE Recon §5 #85 (⭐ NEW 2024+)."""
import asyncio
import requests
from requests.exceptions import RequestException
from fastapi import APIRouter, Depends
from tools._shared import ScanRequest, verify_scan_quota, recon_host
from tools._framework import ScanContext, run_scanner
from tools._payloads.sse_endpoint_discovery_findings import SSE_ENDPOINT_DISCOVERY_FINDING_RULES

router = APIRouter()
SSE_PATHS = ("/", "/events", "/stream", "/sse", "/api/events", "/api/stream", "/api/sse",
             "/notifications", "/subscribe", "/live", "/feed", "/updates", "/push",
             "/realtime", "/api/realtime", "/_/events", "/v1/events")

def _probe_sse(scheme, host, path, timeout=4.0):
    out = {"path": path, "is_sse": False, "status": 0, "content_type": ""}
    url = f"{scheme}://{host}{path}"
    headers = {"Accept": "text/event-stream", "Cache-Control": "no-cache", "User-Agent": "VulnusLab/1.0"}
    try:
        r = requests.get(url, headers=headers, timeout=timeout, stream=True, allow_redirects=False, verify=False)
        out["status"] = r.status_code
        ct = (r.headers.get("content-type") or "").lower()
        out["content_type"] = ct
        if r.status_code == 200 and "text/event-stream" in ct:
            out["is_sse"] = True
        r.close()
    except RequestException:
        pass
    return out

async def gather(ctx):
    host = ctx.host
    endpoints = []
    for scheme in ("https", "http"):
        for path in SSE_PATHS:
            info = await asyncio.to_thread(_probe_sse, scheme, host, path)
            if info["is_sse"]:
                endpoints.append({"url": f"{scheme}://{host}{path}", "content_type": info["content_type"]})
    ctx.state["sse_endpoints"] = endpoints
    ctx.state["sse_endpoint_discovery_total"] = len(endpoints)
    ctx.source(f"text/event-stream × {len(endpoints)}" if endpoints else "no-sse-detected")

INTEL_FIELDS = [("SSE endpoints", "sse_endpoint_discovery_total")]

@router.post("/api/recon/sse_endpoint_discovery")
async def recon_sse_endpoint_discovery(req: ScanRequest, _=Depends(verify_scan_quota)):
    host = recon_host(req.target)
    async def gather_with_display(ctx):
        await gather(ctx)
        eps = ctx.state.get("sse_endpoints") or []
        if eps: ctx.state["endpoints_display"] = ", ".join(e["url"] for e in eps[:5])
    return await run_scanner(host=host, tool="sse_endpoint_discovery",
        gather_func=gather_with_display, finding_rules=SSE_ENDPOINT_DISCOVERY_FINDING_RULES,
        intel_fields=INTEL_FIELDS, flat_field_keys=["sse_endpoints"])

def register(app): app.include_router(router)
