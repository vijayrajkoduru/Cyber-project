"""WebSocket endpoint discovery — VL-FORGE Recon §5 #84 (⭐ NEW 2024+)."""
import asyncio, base64, os
import requests
from requests.exceptions import RequestException
from fastapi import APIRouter, Depends
from tools._shared import ScanRequest, verify_scan_quota, recon_host
from tools._framework import ScanContext, run_scanner
from tools._payloads.websocket_endpoint_discovery_findings import WEBSOCKET_ENDPOINT_DISCOVERY_FINDING_RULES

router = APIRouter()
WS_PATHS = ("/", "/ws", "/wss", "/websocket", "/socket", "/socket.io/?EIO=4&transport=websocket",
            "/sockjs/", "/signalr", "/hub", "/api/ws", "/api/socket", "/api/realtime",
            "/graphql", "/subscriptions", "/notifications", "/events")

def _probe_ws(scheme, host, path, timeout=5.0):
    out = {"path": path, "upgraded": False, "status": 0}
    key = base64.b64encode(os.urandom(16)).decode("ascii")
    url = f"{scheme}://{host}{path}"
    headers = {"Connection": "Upgrade", "Upgrade": "websocket", "Sec-WebSocket-Key": key,
               "Sec-WebSocket-Version": "13", "Origin": f"{scheme}://{host}", "User-Agent": "VulnusLab/1.0"}
    try:
        r = requests.get(url, headers=headers, timeout=timeout, allow_redirects=False, stream=True, verify=False)
        out["status"] = r.status_code
        if r.status_code == 101 and (r.headers.get("upgrade") or "").lower() == "websocket":
            out["upgraded"] = True
            out["server"] = r.headers.get("server", "")
        r.close()
    except RequestException:
        pass
    return out

async def gather(ctx):
    host = ctx.host
    endpoints = []
    for scheme in ("https", "http"):
        for path in WS_PATHS:
            info = await asyncio.to_thread(_probe_ws, scheme, host, path)
            if info["upgraded"]:
                endpoints.append({"url": f"{scheme}://{host}{path}", "server": info.get("server", "")})
    ctx.state["ws_endpoints"] = endpoints
    ctx.state["websocket_endpoint_discovery_total"] = len(endpoints)
    ctx.source(f"http-101-upgrade × {len(endpoints)}" if endpoints else "no-ws-upgrade")

INTEL_FIELDS = [("WebSocket endpoints", "websocket_endpoint_discovery_total")]

@router.post("/api/recon/websocket_endpoint_discovery")
async def recon_websocket_endpoint_discovery(req: ScanRequest, _=Depends(verify_scan_quota)):
    host = recon_host(req.target)
    async def gather_with_display(ctx):
        await gather(ctx)
        eps = ctx.state.get("ws_endpoints") or []
        if eps: ctx.state["endpoints_display"] = ", ".join(e["url"] for e in eps[:5])
    return await run_scanner(host=host, tool="websocket_endpoint_discovery",
        gather_func=gather_with_display, finding_rules=WEBSOCKET_ENDPOINT_DISCOVERY_FINDING_RULES,
        intel_fields=INTEL_FIELDS, flat_field_keys=["ws_endpoints"])

def register(app): app.include_router(router)
