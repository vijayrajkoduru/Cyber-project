"""gRPC reflection discovery — VL-FORGE Recon §5 #83 (⭐ NEW 2024+)."""
import asyncio, socket, ssl
from fastapi import APIRouter, Depends
from tools._shared import ScanRequest, verify_scan_quota, recon_host
from tools._framework import ScanContext, run_scanner
from tools._payloads.grpc_reflection_discovery_findings import GRPC_REFLECTION_DISCOVERY_FINDING_RULES

router = APIRouter()
GRPC_PORTS = (50051, 9090, 8443, 443, 80, 9091)
GRPC_PREFACE = b"PRI * HTTP/2.0\r\n\r\nSM\r\n\r\n"
GRPC_SETTINGS = b"\x00\x00\x00\x04\x00\x00\x00\x00\x00"

def _probe_grpc(host, port, use_tls, timeout=4.0):
    out = {"open": False, "h2": False, "alpn": ""}
    try:
        sock = socket.create_connection((host, port), timeout=timeout)
        out["open"] = True
        if use_tls:
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            ctx.set_alpn_protocols(["h2", "http/1.1"])
            try:
                ssock = ctx.wrap_socket(sock, server_hostname=host)
                out["alpn"] = ssock.selected_alpn_protocol() or ""
                sock = ssock
            except Exception:
                sock.close(); return out
        sock.settimeout(timeout)
        sock.sendall(GRPC_PREFACE + GRPC_SETTINGS)
        resp = sock.recv(64)
        if resp and len(resp) >= 4 and resp[3] == 0x04:
            out["h2"] = True
        sock.close()
    except Exception:
        pass
    return out

async def gather(ctx):
    host = ctx.host
    endpoints = []
    for port in GRPC_PORTS:
        use_tls = port in (443, 8443)
        info = await asyncio.to_thread(_probe_grpc, host, port, use_tls)
        if info.get("open") and info.get("h2"):
            endpoints.append({"port": port, "tls": use_tls, "alpn": info.get("alpn", "")})
    ctx.state["grpc_endpoints"] = endpoints
    ctx.state["grpc_reflection_discovery_total"] = len(endpoints)
    ctx.source(f"http2-handshake on {len(endpoints)} gRPC endpoint(s)" if endpoints else "no-grpc-detected")

INTEL_FIELDS = [("gRPC endpoints", "grpc_reflection_discovery_total")]

@router.post("/api/recon/grpc_reflection_discovery")
async def recon_grpc_reflection_discovery(req: ScanRequest, _=Depends(verify_scan_quota)):
    host = recon_host(req.target)
    async def gather_with_display(ctx):
        await gather(ctx)
        eps = ctx.state.get("grpc_endpoints") or []
        if eps: ctx.state["endpoints_display"] = ", ".join(f"{e['port']}{'/tls' if e['tls'] else ''}" for e in eps)
    return await run_scanner(host=host, tool="grpc_reflection_discovery",
        gather_func=gather_with_display, finding_rules=GRPC_REFLECTION_DISCOVERY_FINDING_RULES,
        intel_fields=INTEL_FIELDS, flat_field_keys=["grpc_endpoints"])

def register(app): app.include_router(router)
